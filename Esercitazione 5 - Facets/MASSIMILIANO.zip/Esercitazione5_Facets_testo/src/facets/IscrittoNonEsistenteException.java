package facets;

@SuppressWarnings("serial")
public class IscrittoNonEsistenteException extends Exception {

}
