package facets;

@SuppressWarnings("serial")
public class ReportNonEsistenteException extends Exception {
	
}
