package test;

public class MyMain {

	public static void main(String[] args) {
		
	}
	
	public static void sopln() {
		sopln("");
	}
	
	public static void sopln(Object object) {
		System.out.println(object);
	}

}
